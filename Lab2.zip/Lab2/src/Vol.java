
public class Vol {
	// attribut d'instance
	private int noVol;
	private String destination;
	private Date date;
	private int nbRes;
	
	
	//attribut de classe
	public static int nombreVols = 0;
	
	// constructeur par default
	Vol() {}
	
	
	// constructeur param�tr�
	Vol(int noVol, String destination, Date date, int nbRes) 
		{
			this.noVol = noVol;
			this.destination = destination;
			setDate(date);
			setNbRes(nbRes);
		}
	
	
	public void modifierVol(int indexAttribut, int entry) 
	{
		switch (indexAttribut) 
		{
		case 0 : this.setNoVol(entry); break;
		case 5 : this.setNbRes(entry); break;
		}
	}
	
	
	// accesseurs/getters
	public int getNoVol()
		{return this.noVol;}
	
	
	public String getDestination()
		{return this.destination;}
	
	
	public Date getDate()
		{return this.date;}
	
	
	public int getNbRes()
		{return this.nbRes;}
	
	
	// mutateurs/setters
	public void setNoVol(int noVol)
		{
			if (noVol > 0)
				{this.noVol = noVol;}
			else
				{throw new IllegalArgumentException("Le num�ro de vol doit �tre sup�rieur � 0!");}
		}
	
	public void setDestination(String destination)
		{this.destination = destination;}
	
	public void setNbRes(int nbRes) 
		{
		if (nbRes >= 0)
			{this.nbRes = nbRes;}
		else
			{throw new IllegalArgumentException("Le nombre de r�servation doit �tre sup�rieur � 0!");}
		}
	
	
	public void setDate(Date date)
		{this.date = date;}
	
	
	public String toString()
		{return this.noVol + " " + this.destination + "\t\t" + this.date + " " + this.nbRes;}
}
