import java.io.*;
import java.util.*;
import javax.swing.*;
import java.awt.Font;

public class TestVol {

	static final String FICHIER_VOL_TEXTE = "src/CieAirRelax.txt";
	
	static String ligne="";
	public static final int MAX_PLACES = 340;
	public static final String CIE = "Cie Air Relax";
	public static final String[] TITRES = {"Liste des vols", 
										   "Ajout d'un vol", 
										   "Retrait d'un vol", 
										   "Modification de la date de d�part", 
										   "R�servation d'un vol", 
										   "Terminer"};
	public static final String[] ATTRIBUT_NO_VOL = {"Num�ro de vol"};
	public static final String[] ATTRIBUTS_VOL = {"skip", "Destination", "Jour de d�part", "Mois de d�part", "Ann�e de d�part", "Nombre de r�servation"};
	
	
	public static ArrayList<Vol> listeVol = new ArrayList<Vol>();
	public static String optionChoisie;
	public static JTextArea sortie = new JTextArea(10, 30);
	public static String regex = "-?[0-9]+";
	
	
/*-------------------------------------------------------------- FONCTION DE D�PART -----------------------------------------------------------------------------*/
	
	public static void chargerVols() throws IOException, FileNotFoundException
	{ 
		String ligne;
		
		listeVol.clear();
		BufferedReader fichier = new BufferedReader(new FileReader(FICHIER_VOL_TEXTE));
		
		// lit une ligne du fichier
		ligne = fichier.readLine();
		
		/* s�pare la ligne en variable � l'aide du substring et des index des charactere. 
		 * enl�ve le surplus d'espace avec trim 
		 * 
		 * NoVol Destination          JJ MM AAAA NbRes  	VARIABLE (JJ = day, MM = month, AAAA = ann�e)
		 * 14567 Toronto              12 04 2002 167    	LIGNE
		 * 01234567890123456789012345678901234567890    	INDEX
		 *          |    1    |    2    |    3    |4    	DIXAINE  
		 */
		while (ligne != null) 
		{	
			int noVol = Integer.parseInt(ligne.substring(0, 5).trim());
			String destination = ligne.substring(6, 27).trim();
			int day = Integer.parseInt(ligne.substring(27, 29).trim());
			int month = Integer.parseInt(ligne.substring(30, 32).trim());
			int year = Integer.parseInt(ligne.substring(33, 37).trim());
			int nbRes = Integer.parseInt(ligne.substring(38).trim());
			
			// creer un nouvel objet Date
			Date date = new Date(day, month, year);
			// cr�er un nouvel objet vol et ajouter � la liste
			listeVol.add(new Vol(noVol, destination, date, nbRes));
			// lire la prochain liste
			ligne = fichier.readLine();
		}		
		fichier.close();
	}	
	
	
	public static String getMenuMessage()
	{ // utilise le tableau de string TITRES pour g�n�rer un menu avec it�ration et retourne le message du menu
		String message = "                   GESTION DES VOLS\n";
		
		for (int i=0 ; i < TITRES.length-1; i++)
			{message += (i+1) + ". " + TITRES[i] + "\n";}
		
		message += "0. " + TITRES[5] + "\n";
		message += "                    Faites votre choix : ";
		return message;
	}
	
		
/*--------------------------------------------------------------------------- MENU -------------------------------------------------------------------------------*/
	
	
	public static void menu() throws FileNotFoundException, IOException
	{
		String program = "on";
		String menu = getMenuMessage(); // g�n�rer le message a afficher dans le menu
		
		chargerVols(); // charger la liste de vol � partir du fichier texte
		
		do 
		{			
			String userInput = JOptionPane.showInputDialog(null, menu /*message generer en haut */, "CIE AIR RELAX", JOptionPane.PLAIN_MESSAGE);
						
			switch (userInput) 
			{
				case "1" : 
					optionChoisie = TITRES[0]; //Liste des vols
					afficherVols(); break;
				case "2" : 
					optionChoisie = TITRES[1]; //Ajout d'un vol
					insererVols(); break;
				case "3" : 
					optionChoisie = TITRES[2]; //Retrait d'un vol
					retirerVol(); break;
				case "4" : 
					optionChoisie = TITRES[3]; //Modification de la date de depart
					modifierDate(); break;
				case "5" : 
					optionChoisie = TITRES[4]; //Reservation d'un vol
					reserverVol(); break;
				case "0" :                     //Terminer
					optionChoisie = TITRES[5];
					terminer();
				default : 
					JOptionPane.showMessageDialog(null, "Vous devez entrer un chiffre entre 0 et 5!", "CHOIX ERRON�", JOptionPane.PLAIN_MESSAGE); break;
			}
		} while (program == "on");
	}
	
	/*---------------------------------------------------------- M�THODE MENU---------------------------------------------------------------------------------*/
	
	
	/*OPTION 1 --------------------------------*/
	
	private static void afficherVols() 
	{ 
		// ent�te du message
		String texte = "\t\t\t" + optionChoisie.toUpperCase() + "\n\n" +
						"Num�ro   Destination\t\tDate d�part\tR�servation     \n";
		
		// � partir de la liste active d'objet Vol ''listeVols'', �crit chaque vol sur une ligne dans un format sp�cifique au besoin
		for (Vol vol : listeVol) 
			{texte += String.format("%-5s", vol.getNoVol()) + "    " +  // format 5 caracteres, remplace par espace si manque
					  String.format("%-23s", vol.getDestination()) +    // format 23 caracteres, remplace par espace si manque
					  vol.getDate() + "\t" + 
					  vol.getNbRes() +"\n";}
		
		sortie.setFont(new Font("Courier", Font.PLAIN, 12));
		sortie.setText(texte); 
		JOptionPane.showMessageDialog(null, sortie, CIE, JOptionPane.PLAIN_MESSAGE);
	}
	
	
	/*OPTION 2 ---------------------------------*/
	
	public static void insererVols() {
		// cr�er un objet vol et date par d�fault sans aucune valeurs au niveau des attribut
		Vol vol = new Vol();
		Date date = new Date();
		
		// configurer le noVol au vol par d�faut
		configurerVol(ATTRIBUT_NO_VOL, vol, date);
		
		//v�rifier si un vol existe d�j� avec le m�me no de vol
		boolean trouve = rechercherVol(vol.getNoVol());
		
		//si oui
		if (trouve == true) 
			{JOptionPane.showMessageDialog(null, "Le num�ro de vol entr� existe d�j�.", optionChoisie.toUpperCase(), JOptionPane.PLAIN_MESSAGE);}
			
		// si non
		else
		{
			//configurer le reste des attributs du vol et de la date par d�fault
			configurerVol(ATTRIBUTS_VOL, vol, date);
			// configurer l'attribut date de l'objet vol avec le nouvel objet date maintenant complet
			vol.setDate(date);
			// ajouter l'objet vol maintenant complet � la liste
			listeVol.add(vol);
		}
	}
	
	
	private static void configurerVol(String[] attributs, Vol vol, Date date) 
	{ /* J'utilisie une liste de constante String repr�sentant les attributs d'objets. Pour chaque string de ma liste (repr�sentant les 
		attributs de mes objets), je demande � l'utilisateur d'assigner une valeur pour configurer mon objet param�tr�. Si un attribut 
		doit �tre convertit en int, le convertit */
		
		String input = "need_Convert";
		
		//Pour chaque string de ma liste, repr�sntant les attributs des objets
		for (String attribut : attributs)
		{	
			do  // demande � l'utilisateur d'entrer une valeur, au besoin convertir en int puis passe au prochain attribut (next)
			{
				if (attribut.equals("skip")) 				// Aucune action effectu�e, next
					{input = "NO_need_Convert";}
				
				else if (attribut.equals("Destination"))    // configure la destination de mon vol, next
					{vol.setDestination(JOptionPane.showInputDialog(null, attribut, optionChoisie.toUpperCase(), 
							JOptionPane.PLAIN_MESSAGE));
					input = "NO_need_Convert";}
				
				else	// Tous les attribut devant �tre convertit en Int
				{
					try  
					{
						//essaie de convertir l'entr�e utilisateur et lance une exception si impossible de convertir
						int userInput = Integer.parseInt(JOptionPane.showInputDialog(null, attribut, optionChoisie.toUpperCase(), 
								JOptionPane.PLAIN_MESSAGE));
						//trouve de quel attribut il s'agit avec l'index de la liste
						int index = Arrays.asList(attributs).indexOf(attribut);
						// refere a une m�thode dans la classe vol et date qui indique quel attribut modifier en fonction de l'index 
						vol.modifierVol(index, userInput); 
						date.modifierDate(index, userInput);
						input = "is_Convert";
					} catch (NumberFormatException e) 	
						{JOptionPane.showMessageDialog(null, "Vous devez entrer un nombre!", 
								optionChoisie.toUpperCase(), JOptionPane.ERROR_MESSAGE);
						}
					catch (IllegalArgumentException s ) {
							String message = s.getMessage();
							JOptionPane.showMessageDialog(null, message, optionChoisie.toUpperCase(), 
									JOptionPane.ERROR_MESSAGE);
					} catch (Exception e) 	
						{JOptionPane.showMessageDialog(null, "Erreur de traitement", 
								optionChoisie.toUpperCase(), JOptionPane.ERROR_MESSAGE);
					}
				}
			} while (input == "need_Convert"); 
		}
	}
	
	
	/*OPTION 3 ---------------------------------*/
	
	public static void retirerVol() throws IOException
	{  
		String messRetrait = "D�sirez-vous vraiment retirer ce vol : \n";
		int noVolUser,
			repUser;
		boolean trouve;
		
		// Demande un noVol � un user, convertir en int, verifie s'il existe d�j� 
		noVolUser = verifierNoVol();
		trouve = rechercherVol(noVolUser);
		
		if (trouve == false) 
			{JOptionPane.showMessageDialog(null, "Le num�ro de vol entr� n'existe pas.", optionChoisie.toUpperCase(), JOptionPane.PLAIN_MESSAGE);}
		
		else // si trouve == true
			
		{ // trouve l'index de l'objet vol dans ma liste 
			int index = rechercherVolIndex(noVolUser);
			messRetrait += listeVol.get(index).getDestination() + " " 
					       + listeVol.get(index).getDate() + "   "
					       + listeVol.get(index).getNbRes();
			// Demande � l'user s'il veut vraiment supprimer le vol
			repUser = JOptionPane.showConfirmDialog(null, messRetrait, optionChoisie.toUpperCase(), JOptionPane.YES_NO_OPTION);
			
			if (repUser == JOptionPane.NO_OPTION)
				{JOptionPane.showMessageDialog(null, "Op�ration annul�e", optionChoisie.toUpperCase(), JOptionPane.PLAIN_MESSAGE);}
			
			else if (repUser == JOptionPane.YES_OPTION)
			{ 
				listeVol.remove(index);
				JOptionPane.showMessageDialog(null, "Le num�ro de vol a �t� retir�", optionChoisie.toUpperCase(), JOptionPane.PLAIN_MESSAGE);
			}
			else // repUser == JOptionPane.CLOSED_OPTION
				{terminer();}
		 }
			
	}
	
	
	/*OPTION 4 ---------------------------------*/
	
	public static void modifierDate() throws IOException 
	{
		String messRetrait = "D�sirez-vous vraiment modifier la date suivante : \n",
			   dateUser;
		String[] partie;
		int noVolUser,
			repUser;
		boolean trouve;
		Date date;
		
		// Demande un noVol � un user, convertir en int, verifie s'il existe d�j�
		noVolUser = verifierNoVol();
		trouve = rechercherVol(noVolUser);
		
		if (trouve == false)
			{JOptionPane.showMessageDialog(null, "Le num�ro de vol entr� n'existe pas.", 
					optionChoisie.toUpperCase(), JOptionPane.PLAIN_MESSAGE);}
		else
		{ // trouve l'index de l'objet vol dans ma liste
			int index = rechercherVolIndex(noVolUser);
			messRetrait += listeVol.get(index).getDestination() + " " 
				       + listeVol.get(index).getDate();
			// Demande � l'user s'il veut vraiment modifier la date
			repUser = JOptionPane.showConfirmDialog(null, messRetrait, optionChoisie.toUpperCase(), JOptionPane.YES_NO_OPTION);
			
			if (repUser == JOptionPane.YES_OPTION)
			{	// demande au user la nouvelle date
				dateUser = JOptionPane.showInputDialog(null, "Entrez la nouvelle date sous cette forme JJ/MM/AAAA", 
						optionChoisie.toUpperCase(), JOptionPane.PLAIN_MESSAGE);
				
				// split le string pour garder seulement les nombres
				partie = dateUser.split("/");
				
				//convertir les nombre en int et cr�e un nouvel objet date
				date = new Date(Integer.parseInt(partie[0]), Integer.parseInt(partie[1]), Integer.parseInt(partie[2]));
				
				// modifier la date du vol choisi
				listeVol.get(index).setDate(date);
				JOptionPane.showMessageDialog(null, "La date a �t� modifi�e", 
						optionChoisie.toUpperCase(), JOptionPane.PLAIN_MESSAGE);
			}
			else if (repUser == JOptionPane.NO_OPTION)
				{JOptionPane.showMessageDialog(null, "Op�ration annul�e", 
						optionChoisie.toUpperCase(), JOptionPane.PLAIN_MESSAGE);}
			else
				{terminer();}
		}
	}
	
	
	/*OPTION 5 ---------------------------------*/	
	
	public static void reserverVol()
	{
		boolean trouve;
		
		// Demande un noVol � un user, convertir en int, verifie s'il existe d�j�
		int noVolUser = verifierNoVol();
		trouve = rechercherVol(noVolUser);
		
		if (trouve == true)
			{verifierPlacesRestantes(noVolUser);}
		else // noVol n'existe pas
			{JOptionPane.showMessageDialog(null, "Le num�ro de vol entr� n'existe pas.", optionChoisie.toUpperCase(), JOptionPane.PLAIN_MESSAGE);}
	}
	
	
	private static void verifierPlacesRestantes(int noVol) 
	{
		// trouve l'index du vol avec le noVol en param�tre
		int index = rechercherVolIndex(noVol);
		String message = "";
		
		// si vol d�ja complet
		if (listeVol.get(index).getNbRes() >= MAX_PLACES)
			{JOptionPane.showMessageDialog(null, "Ce vol est complet", optionChoisie.toUpperCase(), JOptionPane.PLAIN_MESSAGE);}
		else // si pas complet, indique le nb de places restantes et demande combien il en veut
		{ 	 
			 int placeRestantes = (MAX_PLACES - listeVol.get(index).getNbRes());
			 
			 message += listeVol.get(index).getDestination() + "   " + listeVol.get(index).getDate() + 
					 "\nNombre de places restantes : " + placeRestantes +
					 "\n\nCombien de places d�sirez-vous r�server : ";
			 int resUser = Integer.parseInt(JOptionPane.showInputDialog(null, message, optionChoisie.toUpperCase(), JOptionPane.PLAIN_MESSAGE));
			 if (resUser > placeRestantes)
			 	{JOptionPane.showMessageDialog(null, "Vous ne pouvez pas r�server un nombre de place sup�rieure "
			 								  + "au nombre de places restantes", optionChoisie.toUpperCase(), 
			 								  JOptionPane.PLAIN_MESSAGE);}
			 else {
			 listeVol.get(index).setNbRes(listeVol.get(index).getNbRes() + resUser);
			 JOptionPane.showMessageDialog(null, "R�servation effectu�e", optionChoisie.toUpperCase(), 
					  JOptionPane.PLAIN_MESSAGE);}
		}
	}
	
	
	/*OPTION 0 ---------------------------------*/	
		
	public static void terminer() throws IOException 
	{
	sauvegarderFichier(); 
	JOptionPane.showMessageDialog(null, "Au revoir!", optionChoisie.toUpperCase(), JOptionPane.PLAIN_MESSAGE);
	System.exit(0);		
	}
	
	
	public static void sauvegarderFichier() throws IOException {
		BufferedWriter tmpVolWrite = new BufferedWriter(new FileWriter(FICHIER_VOL_TEXTE));
		listeVol.forEach((vol) -> {
			String tmpDestination = vol.getDestination();
			while(tmpDestination.length() < 20) {
				tmpDestination += " ";
			}
			ligne=vol.getNoVol()+tmpDestination+
					vol.getDate().getDay()+vol.getDate().getMonth()+vol.getDate().getYear()+vol.getNbRes();
			try {
				tmpVolWrite.write(ligne);
				tmpVolWrite.newLine();
			} catch (IOException e) {
				System.out.println("Problème d'écriture dans le fichier");
			}
		});
		tmpVolWrite.close();
	}
	
	
	
	/*----------------------------------------FONCTIONS UTILITAIRES----------------------------------------------------------*/
	
	private static int rechercherVolIndex(int noVol) 
	{
		int index = -1;
		for (Vol vol : listeVol) 
			{if (noVol == vol.getNoVol()) {index = listeVol.indexOf(vol);}		}
		return index;
	}
	
	
	private static boolean rechercherVol(int noVol) 
	{
		boolean trouve = false;
		
		for (int i=0; i < listeVol.size() && trouve == false; i++) 
			{if (noVol == listeVol.get(i).getNoVol()) {trouve = true;}
			}
		return trouve;
	}
	
	
	private static int verifierNoVol()
	{
		String noVol,
			   entry = "string";
		do 
		{
			noVol = JOptionPane.showInputDialog(null, ATTRIBUT_NO_VOL, optionChoisie.toUpperCase(), JOptionPane.PLAIN_MESSAGE);
			
			if (noVol.matches(regex)) 
				{entry = "number";}
			else 
				{JOptionPane.showMessageDialog(null, "Vous devez entrer un nombre!",
						optionChoisie.toUpperCase(), JOptionPane.ERROR_MESSAGE);}
		} while (entry.equals("string"));	
		
		return Integer.parseInt(noVol);
	}
	
	
	/*----------------------------------------------- MAIN -------------------------------------------------------------*/
	
	public static void main(String[] args) throws FileNotFoundException, IOException {
		
	menu();
			
	}

}
